public enum ActionType {
    ACCEPT,SHIFT,REDUCE
}
